
<?php

session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'papersgchospital';
$DATABASE_PASS = 'zS70j3yYAImt';
$DATABASE_NAME = 'papersgchospital';

$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

?>

<html>
<head>
	<meta charset="utf-8">
	<title>Gestió Fundacions</title>
        <link href="styleform.css" rel="stylesheet" type="text/css">
        <link href="minimal.css" rel="stylesheet" href="minimal.css">      

</head>

<body>	
    
 <div class="topnav"> 
   <a href="#home"> <?php echo $_SESSION['Fundacio'] ?></a>
   <a href="#home"> <?php echo $_SESSION['NomCognoms'] ?></a>
   <a href="brwFitxes.php">Fitxes</a>
   <a class="active"  href="filtre.php">Resum</a>
   <a href="brwActivitats.php"> Activitats</a>
   <a href="cobraments.php">Cobraments</a>
   <a href="logout.php">Sortir</a>
</div>
   
     <hr>
     <div class="datagrid">
      <table>
        <tr><th>Total de Fitxes: 
        <?php 
        $datos = $con-> query("SELECT count(*) numReg FROM afimatfitxa");
        $reg = mysqli_fetch_array($datos);
        echo $reg['numReg'];
        ?>  </th>
       </tr>
       
        <tr><th>Total de Fitxes Actives: 
        <?php 
        $datos = $con-> query("SELECT count(*) numReg FROM afimatfitxa where Estat='Alta'");
        $reg = mysqli_fetch_array($datos);
        echo $reg['numReg'];
        ?>  </th>
       </tr>
        <tr><th>Total de Fitxes Baixa: 
        <?php 
        $datos = $con-> query("SELECT count(*) numReg FROM afimatfitxa where Estat='Baixa'");
        $reg = mysqli_fetch_array($datos);
        echo $reg['numReg'];
        ?>  </th>
       </tr>       
        <tr><th>Total de Socis: 
        <?php 
        $datos = $con-> query("SELECT count(*) numReg FROM afimatfitxa where Tipus='Soci'");
        $reg = mysqli_fetch_array($datos);
        echo $reg['numReg'];
        ?>  </th>
       </tr>      
        <tr><th>Total de Professionals: 
        <?php 
        $datos = $con-> query("SELECT count(*) numReg FROM afimatfitxa where Tipus='Professional'");
        $reg = mysqli_fetch_array($datos);
        echo $reg['numReg'];
        ?>  </th>
       </tr>           
        <tr><th>Total de Voluntaris: 
        <?php 
        $datos = $con-> query("SELECT count(*) numReg FROM afimatfitxa where Tipus='Voluntari'");
        $reg = mysqli_fetch_array($datos);
        echo $reg['numReg'];
        ?>  </th>
       </tr>     
        <tr><th>Suma Quotes (€): 
        <?php 
        $datos = $con-> query("SELECT sum(ImportCuota) numReg FROM afimatfitxa where Tipus='Soci' and Estat='Alta'");
        $reg = mysqli_fetch_array($datos);
        echo $reg['numReg'];
        ?> 
       </tr>         
        <tr><th>Activitats: 
        <?php 
        $datos = $con-> query("SELECT YEAR(Data) any,count(*) numReg FROM afimatactivitat group by YEAR(Data)");
        
        while ($reg = mysqli_fetch_array($datos)) {       
        echo " [ " . $reg['any'] . ' --> ';
        echo $reg['numReg'] . "] ";
        }
        ?> 
                
       </tr> 
      </table>
     </div>
</body>
</html>
