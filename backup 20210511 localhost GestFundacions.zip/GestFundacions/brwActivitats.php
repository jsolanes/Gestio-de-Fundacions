<?php

session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'papersgchospital';
$DATABASE_PASS = 'zS70j3yYAImt';
$DATABASE_NAME = 'papersgchospital';

$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
$datos = $con-> query("SELECT * FROM afimatactivitat order by DATA Desc");

?>

<html>
<head>
	<meta charset="utf-8">
	<title>Gestió Fundacions</title>
        <link href="styleform.css" rel="stylesheet" type="text/css">
        <link href="minimal.css" rel="stylesheet" href="minimal.css">     
</head>

<body>	    
 <div class="topnav"> 
   <a href="#home"> <?php echo $_SESSION['Fundacio'] ?></a>
   <a href="#home"> <?php echo $_SESSION['NomCognoms'] ?></a>
   <a href="brwFitxes.php">Fitxes</a>
   <a href="filtre.php">Resum</a>
   <a class="active" href="brwActivitats.php"> Activitats</a>
   <a href="cobraments.php">Cobraments</a>
   <a href="logout.php">Sortir</a>
</div>
  
     <hr>
     <div class="datagrid">
      <table>
        <tr><th style="width:100px;">Data</th><th>Nom</th><th>LLoc</th></tr>
        <?php  while ($user = mysqli_fetch_array($datos)){
        echo "<tr>";
            $link = $user['idActivitat'];
            $link = "<a href=editActivitat.php?idActivitat=" . $link . " </a>";
            echo "<td style='width:100px;'>"; echo $user['Data']; echo "</td>";
            echo "<td>"; echo $link; echo $user['Nom']; echo "</td>";
            echo "<td>"; echo $user['LLoc']; echo "</td>";
            echo "<td>"; echo $user['TotalAssistents']; echo "</td>";           
       echo "</tr>"; 
        }
    ?>        
      </table>
    </div>    

</body>
</html>