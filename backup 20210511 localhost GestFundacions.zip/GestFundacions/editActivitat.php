<?php

session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'papersgchospital';
$DATABASE_PASS = 'zS70j3yYAImt';
$DATABASE_NAME = 'papersgchospital';

$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
$postIdActivitat = $_REQUEST["idActivitat"];

$query = "SELECT * FROM afimatactivitat WHERE idActivitat = ";
$query = $query . $postIdActivitat;
$datos = $con-> query($query);
$row = mysqli_fetch_array($datos);

?>

<html>
<head>
	<meta charset="utf-8">
	<title>Gestió Fundacions</title>
        <link href="style.css" rel="stylesheet" type="text/css">   
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <!-- <link href="minimal.css" rel="stylesheet" >
        <link href="delete.css" rel="stylesheet" type="text/css"> -->
        <link href="tableEdit.css" rel="stylesheet">

</head>
   <body>
   <div class="topnav"> 
   <a href="#home"> <?php echo $_SESSION['Fundacio'] ?></a>
   <a href="#home"> <?php echo $_SESSION['NomCognoms'] ?></a>
   <a href="brwFitxes.php">Fitxes</a>
   <a href="filtre.php">Resum</a>
   <a class="active" href="brwActivitats.php"> Activitats</a>
   <a href="cobraments.php">Cobraments</a>
   </div>     
   <hr>
   <form action="commitAct.php" method="post">       
       <div class="datagrid">
       <table>
        <tbody> 
            <tr><td><label for="Data">Data</label> </td><td><input type="date" name="Data" value="<?=$row['Data']?>" maxlength="75"></td></tr>
            <tr><td><label for="Nom">Nom</label></td><td><input type="text" name="Nom" value="<?=$row['Nom']?>" maxlength="300"></td></tr>
            <tr><td><label for="Data">LLoc</label> </td><td><input type="text" name="LLoc" value="<?=$row['LLoc']?>" maxlength="300"></td></tr>   
            <tr><td><label for="TotalAssistents">Num Assistents</label> </td><td><input type="text" name="TotalAssistents" value="<?=$row['TotalAssistents']?>" maxlength="300"></td></tr>   
            <tr><td><input type="hidden" name="idActivitat" value="<?=$row['idActivitat']?>" ></td></tr>    
        </tbody>       
        </table>
       </div>
       <hr>
   <table>
      
    <tr align="left"><td><button type="submit" class="btn btn-success" name="boton" value="Upd" style='width:200px'>ACTUALITZAR</button>
    <button type="submit" class="btn btn-primary" name="boton" value="New"style='width:200px'>NOVA</button>
    <button type="submit" class="btn btn-danger" name="boton" value="Del" style='width:200px'>BORRAR</button></td>

    </table>    
   
   
   </form>       
    <hr>
    
  </body>
</html>
