<?php

session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'papersgchospital';
$DATABASE_PASS = 'zS70j3yYAImt';
$DATABASE_NAME = 'papersgchospital';

$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

$boton = $_POST["boton"];
$postIdActivitat = $_REQUEST["idActivitat"];

switch ($boton) {
    case 'New':

       $query = "insert into afimatactivitat (Data,Nom,TotalAssistents,Lloc) values ('";

       $query = $query . $_REQUEST["Data"] . "',";
       $query = $query . "'" . $_REQUEST["Nom"] . "',";       
       $query = $query . "'" . $_REQUEST["TotalAssistents"] . "',";   
       $query = $query . "'" . $_REQUEST["LLoc"] . "'";
       $query = $query . ")";
     
       $datos = $con-> query($query); 
         
       header('Location: brwActivitats.php');
       
        break;
    case 'Upd':
        
       $query = "update afimatactivitat SET ";
        
       $query = $query = $query . "Data = '" . $_REQUEST["Data"] . "', ";
       $query = $query = $query . "Nom = '" . $_REQUEST["Nom"] . "', ";       
       $query = $query = $query . "LLoc = '" . $_REQUEST["LLoc"] . "', ";       
       $query = $query = $query . "TotalAssistents = " . $_REQUEST["TotalAssistents"];         
       
       $query = $query . " WHERE idActivitat = ". $postIdActivitat;
                  
       $datos = $con-> query($query); 
       header('Location: brwActivitats.php');
       break;
    
    case 'Del': {
       $query = "DELETE FROM afimatactivitat WHERE idActivitat = ";
       $query = $query . $postIdActivitat;
       $datos = $con-> query($query); 
       header('Location: brwActivitats.php');
        }
        break;    
      
}
?>

<html>	
	<body>
         <?php   
    echo $query; ?>
	</body>
</html>