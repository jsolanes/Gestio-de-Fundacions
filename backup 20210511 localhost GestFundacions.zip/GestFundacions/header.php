<div id="menufijo">
        <a href="https://tusitio.com"><img src="ruta/a/tulogo.png" alt="" /></a>
        <ul class="menu-fijo">
                <li><a href="https://tusitio.com">Inicio</a></li>
                <li><a href="#header" id="srolltotop">Subir</a></li>
        </ul>
</div><!-- #menufijo -->