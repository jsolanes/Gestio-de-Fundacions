<?php

session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'papersgchospital';
$DATABASE_PASS = 'zS70j3yYAImt';
$DATABASE_NAME = 'papersgchospital';

$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
$postIdFitxa = $_REQUEST["idFitxa"];

$query = "SELECT * FROM afimatFitxa WHERE idFitxa = ";
$query = $query . $postIdFitxa;
$datos = $con-> query($query);
$row = mysqli_fetch_array($datos);

?>

<html>
<head>
	<meta charset="utf-8">
	<title>Gestió Fundacions</title>
        <link href="style.css" rel="stylesheet" type="text/css">   
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <!-- <link href="minimal.css" rel="stylesheet" >
        <link href="delete.css" rel="stylesheet" type="text/css"> -->
        <link href="tableEdit.css" rel="stylesheet">

</head>
   <body>
   <div class="topnav"> 
   <a href="#home"> <?php echo $_SESSION['Fundacio'] ?></a>
   <a href="#home"> <?php echo $_SESSION['NomCognoms'] ?></a>
   <a class="active" href="brwFitxes.php">Fitxes</a>
   <a href="filtre.php">Resum</a>
   <a href="brwActivitats.php"> Activitats</a>
   <a href="cobraments.php">Cobraments</a>
   <a href="logout.php">Sortir</a>   
   </div>     
   <hr>
   <form action="commit.php" method="post">       
       <div class="datagrid">
       <table>
        <tbody> 
            <tr>
                <td><label for="NomCognoms">Nom i Cognoms</label></td><td><input type="text" name="NomCognoms" value="<?=$row['NomCognoms']?>" maxlength="32"></td>
                <td><label for="Tipus">Tipus</label> </td><td><input type="text" name="Tipus" value="<?=$row['Tipus']?>" maxlength="75"></td>
                <td><label for="Email">Email</label></td><td><input type="text"  name="Email" value="<?=$row['Email']?>" maxlength="75"></td>
                <td><label for="Estat">Estat</label></td><td><input type="text"  name="Estat" value="<?=$row['Estat']?>" maxlength="75"></td>
            </tr>
            <tr>
                <td><label for="Telefon">Telefon</label></td><td><input type="text"  name="Telefon" value="<?=$row['Telefon']?>" maxlength="75"></td>
                <td><label for="DniNif">DniNif</label></td><td><input type="text" name="DniNif" value="<?=$row['DniNif']?>" maxlength="75"></td>
                <td><label for="DataNaixament">Data de Naixement</label></td><td><input type="date" name="DataNaixament" value="<?=$row['DataNaixament']?>" maxlength="75"></td>
            </tr>
            <tr>
                <td> <label for="Adress">Adreça</label></td><td> <input type="text" name="Adress" value="<?=$row['Adress']?>" maxlength="150"></td>
                <td><label for="CPostal">Codi Postal</label></td><td><input type="text" name="CPostal"  value="<?=$row['CPostal']?>" maxlength="75"></td>
                <td> <label for="Poblacio">Poblacio</label></td><td> <input type="text" name="Poblacio" value="<?=$row['Poblacio']?>" maxlength="75"></td>
                <td><label for="Provincia">Provincia</label></td><td>  <input type="text" name="Provincia" value="<?=$row['Provincia']?>" maxlength="75"></td>
             </tr>
             
             <tr>
                <td><label for="PeriodicitatCuota">Periodicitat de la Cuota</label></td><td> <input type="text" name="PeriodicitatCuota" value="<?=$row['PeriodicitatCuota']?>" maxlength="75"></td>
                <td><label for="ImportCuota">Import de la Cuota</label></td><td><input type="number" name="ImportCuota" value="<?=$row['ImportCuota']?>" maxlength="75"></td>
                <td> <label for="IBAN">IBAN</label></td><td><input type="text" name="IBAN" value="<?=$row['IBAN']?>" maxlength="75"></td>
             </tr>
             
             <tr>
                <td><label for="DataAlta">Data Alta Fitxa</label></td><td><input type="date" name="DataAlta" value="<?=$row['DataAlta']?>" maxlength="75"></td>
                <td><label for="Comenshaconegut">Com ens ha Conegut</label></td><td><input type="text" name="Comenshaconegut" value="<?=$row['Comenshaconegut']?>" maxlength="75"></td>                
                <td><label for="DataBaixa">Data Baixa Fitxa</label></td><td><input type="date" name="DataBaixa" value="<?=$row['DataBaixa']?>" maxlength="75"></td>
                <td><label for="MotiusBaixa">Motius de la Baixa</label></td><td><input type="text" name="MotiusBaixa" value="<?=$row['MotiusBaixa']?>" maxlength="75"></td>
                <td><input type="hidden" name="idFitxa" value="<?=$row['idFitxa']?>" maxlength="32"></td>
             </tr>
        </tbody>
        <table>
              <tr><td><label for="Notes">Notes</label></td></tr>
              <tr><td><input type="text" name="Memo" style="WIDTH: 1000px; HEIGHT: 98px" size=32 value="<?=$row['Memo']?>"></td></tr>
        </table>
        </table>
       </div>
   <table>
    <tr align="left"><td><button type="submit" class="btn btn-success" name="boton" value="Upd" style='width:200px'>ACTUALITZAR FITXA</button>
    <button type="submit" class="btn btn-primary" name="boton" value="New"style='width:200px'>NOVA FITXA</button>
    <button type="submit" class="btn btn-warning" name="boton" value="Baixa" style='width:200px'>DONAR DE BAIXA</button>
    <button type="submit" class="btn btn-danger" name="boton" value="Del" style='width:200px'>BORRAR FITXA DEFINITIU</button></td>
   </table>      
   
   </form>       
    <hr>
    
  </body>
</html>
