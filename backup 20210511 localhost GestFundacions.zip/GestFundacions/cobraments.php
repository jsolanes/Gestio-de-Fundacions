<?php

session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'papersgchospital';
$DATABASE_PASS = 'zS70j3yYAImt';
$DATABASE_NAME = 'papersgchospital';

$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
$datos = $con-> query("SELECT * FROM afimatfitxa");

?>
<html>
<head>
	<meta charset="utf-8">
	<title>Gestió Fundacions</title>
        <link href="styleform.css" rel="stylesheet" type="text/css">
        <link href="minimal.css" rel="stylesheet" href="minimal.css">      
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>	
    
 <div class="topnav"> 
   <a href="#home"> <?php echo $_SESSION['Fundacio'] ?></a>
   <a href="#home"> <?php echo $_SESSION['NomCognoms'] ?></a>
   <a href="brwFitxes.php">Fitxes</a>
   <a href="filtre.php">Resum</a>
   <a href="brwActivitats.php"> Activitats</a>
   <a class="active"  href="cobraments.php">Cobraments</a>
   <a href="logout.php">Sortir</a>
</div>
  <?php
            echo "<br>";
            echo " <p class='bg-danger text-white'>Encara no està Implementant.. Aviat!!</p>";  
  ?>
    </body>
</html>
