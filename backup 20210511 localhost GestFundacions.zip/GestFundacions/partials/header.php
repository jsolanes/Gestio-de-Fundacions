<header>
  <a href="/GestFundacions">Gestió de Fundacions</a>
</header>