<?php

session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'papersgchospital';
$DATABASE_PASS = 'zS70j3yYAImt';
$DATABASE_NAME = 'papersgchospital';

$con = new mysqli($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

$boton = $_POST["boton"];
$postIdFitxa = $_REQUEST["idFitxa"];

switch ($boton) {
    case 'New':

       $query = "insert into afimatfitxa (NomCognoms,Tipus,Email,Estat,Telefon,DniNif,DataNaixament,Adress,CPostal,Poblacio,Provincia,PeriodicitatCuota,ImportCuota,IBAN,DataAlta,Memo,Comenshaconegut,MotiusBaixa) values ('";

       $query = $query . $_REQUEST["NomCognoms"] . "',";
       $query = $query . "'" . $_REQUEST["Tipus"] . "',";       
       $query = $query . "'" . $_REQUEST["Email"] . "',";
       $query = $query . "'" . $_REQUEST["Estat"] . "',";
       $query = $query . "'" . $_REQUEST["Telefon"] . "',";
       $query = $query . "'" . $_REQUEST["DniNif"] . "',";
       
       $dNaix = $_REQUEST["DataNaixament"];      
       if ($dNaix == '' ){
          $query = $query . "'1900/01/01',";
        }     
        else {
         $query = $query . "'" . $dNaix . "',";        
       };         
      
       $query = $query . "'" . $_REQUEST["Adress"] . "',";
       $query = $query . "'" . $_REQUEST["CPostal"] . "',";
       $query = $query . "'" . $_REQUEST["Poblacio"] . "',";       
       $query = $query . "'" . $_REQUEST["Provincia"] . "',";  
       
       $query = $query . "'" . $_REQUEST["PeriodicitatCuota"] . "',";  
       $query = $query . "'" . $_REQUEST["ImportCuota"] . "',";  
       $query = $query . "'" . $_REQUEST["IBAN"] . "',";      
                   
       $fechaActual = date('Y/m/d');
       $query = $query . "'" . $fechaActual . "',";         
       $query = $query . "'" . $_REQUEST["Memo"] . "',";  
       $query = $query . "'" . $_REQUEST["Comenshaconegut"] . "',"; 
       $query = $query . "'" . $_REQUEST["MotiusBaixa"] . "'";  
       $query = $query . ")";
     
       $datos = $con-> query($query); 
       
       $var = "Recorda signar Document CONSENTIMENT";
       echo "<script> alert('".$var."'); </script>";
       header('Location: /GestFundacions/brwFitxes.php');
       
        break;
    case 'Upd':
        
       $query = "update afimatfitxa SET ";
        
       $query = $query = $query . "NomCognoms = '" . $_REQUEST["NomCognoms"] . "', ";
       $query = $query = $query . "Estat = '" . $_REQUEST["Estat"] . "', ";       
       $query = $query = $query . "Tipus = '" . $_REQUEST["Tipus"] . "', ";       
       $query = $query = $query . "DniNif = '" . $_REQUEST["DniNif"] . "', ";
       $query = $query = $query . "Email = '" . $_REQUEST["Email"] . "', ";       
       $query = $query = $query . "Telefon = '" . $_REQUEST["Telefon"] . "', ";       
       $query = $query = $query . "DataNaixament = '" . $_REQUEST["DataNaixament"] . "', ";
       $query = $query = $query . "Adress = '" . $_REQUEST["Adress"] . "', ";
       $query = $query = $query . "CPostal = '" . $_REQUEST["CPostal"] . "', ";
       $query = $query = $query . "Poblacio = '" . $_REQUEST["Poblacio"] . "', ";
       $query = $query = $query . "Provincia = '" . $_REQUEST["Provincia"] . "', ";       
       $query = $query = $query . "PeriodicitatCuota = '" . $_REQUEST["PeriodicitatCuota"] . "', ";       
       $query = $query = $query . "ImportCuota = '" . $_REQUEST["ImportCuota"] . "', ";          
       $query = $query = $query . "IBAN = '" . $_REQUEST["IBAN"] . "', ";   
       $query = $query = $query . "DataAlta = '" . $_REQUEST["DataAlta"] . "', ";    
       $query = $query = $query . "Comenshaconegut = '" . $_REQUEST["Comenshaconegut"] . "', ";          
       $query = $query = $query . "Memo = '" . $_REQUEST["Memo"] . "', ";   
       $query = $query = $query . "MotiusBaixa = '" . $_REQUEST["MotiusBaixa"] . "' ";   
       
       $query = $query . " WHERE idFitxa = ". $postIdFitxa;
                  
       $datos = $con-> query($query); 
       header('Location: brwFitxes.php');
       break;
    
    case 'Del': {
       $query = "DELETE FROM afimatfitxa WHERE idFitxa = ";
       $query = $query . $postIdFitxa;
       $datos = $con-> query($query); 
       header('Location: /GestFundacions/brwFitxes.php');
        }
        break;    
    
    case 'Baixa': {
       $query = "update afimatfitxa SET ";       
       $Baixa = date('Y/m/d');     
       $query = $query = $query . "Estat = 'Baixa', ";        
       $query = $query = $query . "DataBaixa = '" . $Baixa . "', ";     
       $query = $query = $query . "MotiusBaixa = '" . $_REQUEST["MotiusBaixa"] . "'";
       
       $query = $query . " WHERE idFitxa = ". $postIdFitxa;                  
       $datos = $con-> query($query); 
        header('Location: /GestFundacions/brwFitxes.php');
       
        }
        break;
}
?>

<html>	
	<body>
         <?php   
    echo $query; ?>
	</body>
</html>